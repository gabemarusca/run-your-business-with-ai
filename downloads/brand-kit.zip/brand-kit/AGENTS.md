# Brand kit rules

- All visual output uses `tokens.css`.
- Never invent a color, font, or spacing value not defined in `tokens.css`.
- Start from the matching file in `templates/`.
- If a component does not exist, add it to `templates/` rather than inlining it.
- Verbatim text, including quotes, prices, and names, passes through unchanged.
