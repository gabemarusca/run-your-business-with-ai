# Start here

This folder works in a Claude Project, Cowork folder, ChatGPT Project, or Codex repo.

1. Put logo and font files in `assets/`.
2. Put one or two approved past assets in `examples/`.
3. Paste the setup prompt below into your AI.
4. Answer one question at a time.
5. Ask the AI to fill in `tokens.css` and `BRAND-BRIEF.md` from your answers.
6. Review both files before creating an asset.

## Setup prompt

Copy everything between the lines and paste it into your AI with this folder open or uploaded.

---

I have a brand kit folder open. It contains tokens.css, BRAND-BRIEF.md, an assets folder with my logo and font files, an examples folder with one or two past assets I consider on-brand, and a templates folder. Your job is to set it up for my business, and I want you to interview me instead of guessing.

Ask me one question at a time, in this order, and wait for my answer before the next question:

1. My business name and what it does, in one sentence.
2. My main brand color and any secondary colors. If I only know them roughly ("dark blue"), look at the files in assets and examples and propose exact hex codes for me to confirm.
3. My fonts, for headings and for body text. If I do not know, propose one pairing based on the examples and one safe fallback.
4. Three words that describe how my brand should sound, and one word it should never sound like.
5. Things I never want to see in my materials: colors, phrases, styles, layouts.
6. Which file in examples is the best reference for "this looks right," and what specifically makes it right.

When the interview is done: fill in tokens.css with the confirmed values, complete every section of BRAND-BRIEF.md from my answers, and show me both files for approval before touching anything else. Do not invent a value I did not confirm. If a question was left unanswered, leave that field marked as [TO CONFIRM] rather than filling it with a guess.

---

## Use the kit

Start from the matching file in `templates/`. Keep approved examples in `examples/` so the AI can compare new work with your standard.
