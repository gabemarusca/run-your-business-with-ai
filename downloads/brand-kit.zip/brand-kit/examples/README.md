Put one or two approved past assets here so the AI can match your bar; label one GOOD and, optionally, one BAD with a note on why.
