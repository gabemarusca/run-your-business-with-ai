# Brand brief

## Colors

- Primary: `#[HEX]`
- Secondary: `#[HEX]`
- Accent: `#[HEX]`
- Background: `#[HEX]`
- Text: `#[HEX]`

## Typography

- Display font: [FONT]
- Body font: [FONT]
- Approved weights: [WEIGHTS]

## Logo usage

- Primary logo: [FILE]
- Alternate logo: [FILE]
- Clear-space rule: [RULE]
- Minimum size: [SIZE]
- Background restrictions: [RESTRICTIONS]

## Tone of voice

### Do

- [TONE WORD]
- [TONE WORD]

### Do not

- [TONE TO AVOID]
- [TONE TO AVOID]

## Banned words

- [WORD]
- [WORD]
